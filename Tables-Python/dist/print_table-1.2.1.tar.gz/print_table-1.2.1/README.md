# print_table<br>
**A simple package to print responsive tables**<br>

**Usage:**


    from print_table import Table

    Table(numberOfCols=2).head(['Title1','Title2']).row(['Row1Col1','Row1Col2']).printTable()
