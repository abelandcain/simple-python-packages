# renamelocker

**Simple package to rename files with extension to hide videos and images**


**Usage:**

Navigate to the folder containing files you whisth to rename, then type **renamelocker** comand in comand prompt


**Try:**
>pip3 install renamelocker
       