import renamelocker.functions as functions
def main():
    functions.main()